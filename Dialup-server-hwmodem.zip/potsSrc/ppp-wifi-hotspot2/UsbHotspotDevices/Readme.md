## this setup will let the phone connect with Linux board as USB ethernet card
```sh
# to append some text to file
cat <<EOF >> outputfile
some lines
of text
EOF
```
