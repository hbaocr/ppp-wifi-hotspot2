#!/bin/bash
sudo ./install-facilities.sh
sudo ./setup-usb-otg-ethernet-g_ether.sh
#sudo setup-usb0-ip.sh
#sudo ./setup-iptables.sh
sudo ./install-web-api.sh