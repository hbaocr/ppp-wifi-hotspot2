#!/bin/bash

#######################################################
echo "PPP config: "
sudo ./ppp-config/ppp-config-generator.sh


