## To install and start ppp dial up server
```sh
sudo  ./install.sh   
```

## Only start ppp-dial up server ( this usually from 2nd start )

```sh
sudo  ./start-dialup-server.sh   
```
