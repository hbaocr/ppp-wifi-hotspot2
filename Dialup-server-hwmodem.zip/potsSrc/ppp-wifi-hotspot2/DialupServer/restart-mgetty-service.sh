#!/bin/bash
sudo systemctl restart mgetty@tntb0.service
sudo systemctl restart mgetty@tntb1.service
sudo systemctl restart mgetty@tntb2.service
sudo systemctl restart mgetty@tntb3.service
sudo systemctl restart mgetty@tntb4.service
sudo systemctl restart mgetty@tntb5.service
sudo systemctl restart mgetty@tntb6.service
sudo systemctl restart mgetty@tntb7.service
