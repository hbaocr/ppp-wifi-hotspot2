
#ioctl(SIOCSIFMTU): Permission denied (line 1201)

https://github.com/ppp-project/ppp/blob/c2881a6b71a36d28a89166e82820dc5e711fd775/pppd/sys-linux.c#L1297


#Couldn't get PPP statistics: Permission denied

https://github.com/ppp-project/ppp/blob/c2881a6b71a36d28a89166e82820dc5e711fd775/pppd/sys-linux.c#L1482


#ioctl(SIOCSIFADDR): Permission denied (line 2386)

https://github.com/ppp-project/ppp/blob/c2881a6b71a36d28a89166e82820dc5e711fd775/pppd/sys-linux.c#L3019
