#!/bin/sh
gcc -o chat chat.c -static