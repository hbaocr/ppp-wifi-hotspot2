## Original src code

https://raw.githubusercontent.com/ppp-project/ppp/master/chat/chat.c
